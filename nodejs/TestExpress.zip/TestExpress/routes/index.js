var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  // var userName = req.query.points,
  //  userPwd = req.query.userPwd,
  //  userName2 = req.param('userName'),
  var point =  req.param('points');
   // userPwd2 = req.param('userPwd');//注意req.query,req.param

  console.log('point:'+point);
  //console.log('point:'+typeof(point),eval(point));
  // console.log('req.query用户名:'+userName);
  // console.log('req.query密码:'+userPwd);
  // console.log('req.param用户名:'+userName2);
  // console.log('req.param密码:'+userPwd2);
  var a = eval(point);

  // res.render('index', { title: '提交表单及接收参数示例' });
  res.render('index', { title: 'Express', 'result': a,});
});

module.exports = router;
