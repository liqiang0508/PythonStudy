# Drawing a real-time graph

This example demonstrates how to use the streaming data to draw a realtime graph

Install dependencies with 

    npm install

Start the application with 

    node app.js
