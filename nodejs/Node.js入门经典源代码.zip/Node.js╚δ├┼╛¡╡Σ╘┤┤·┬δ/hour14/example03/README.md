# Sending data to the browser with Socket.io

This example demonstrates how to parse the streamed data from Twitter

Install dependencies with 

    npm install

Start the application with 

    node app.js
