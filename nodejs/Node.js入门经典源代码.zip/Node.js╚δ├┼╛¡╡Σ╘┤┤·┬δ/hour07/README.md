# Chapter 7

Chapter 7 gives further detail on [Express][1], specifically routing

1. Routing in Express
2. Creating a GET route
3. Creating a POST route
4. Using parameters in routes
5. Passing local variables to the view layer
6. Solution to Quiz question 3

[1]: http://expressjs.com
