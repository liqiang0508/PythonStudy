# Chapter 12

Chapter 12 introduces [socket.io][1].

1. Connecting clients
2. Sending data from the server to clients
3. Sending data from clients to the server
4. Sending data both ways

[1]: http://socket.io


