# Using callbacks for validation

This example demonstrates how a callback can be used to check if the username is already in the list that the server knows about. 

Install dependencies with 

    npm install

Start the application with 

    node app.js


