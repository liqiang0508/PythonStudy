# An HTTP client with node.js

In this example you create an HTTP client to check whether a website is up. The script checks that the response code is 200

Start the script with

    node server.js

[1]: http://127.0.0.1:3000
