# Daemonising the HTTP client 

We can daemonise the HTTP client to create a script that regularly checks a server.

Start the script with

    node server.js

[1]: http://127.0.0.1:3000
