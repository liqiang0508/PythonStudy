# Hello World Server

This example illustrates a hello world node.js server

Start the server with

    node server.js

Then open your browser at [http://127.0.0.1:3000][1]

[1]: http://127.0.0.1:3000
