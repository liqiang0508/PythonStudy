var cheeses = ['Maroilles','Brie de Meaux','Stinking Bishop'];
for(var i=0;i<cheeses.length;i++){
  console.log(cheeses[i]);
}

