# Chapter 2

Chapter 2 shows how to use npm to manage Node.js packages

1. Installing dependencies with npm
2. Using a package.json file

