var _ = require('underscore');
_.each([1, 2, 3], function(num){ 
  console.log("underscore.js says " + num);
});
