# Using a package.json file

This example illustrates using a package.json file to declare dependencies

Install dependencies with 

    npm install

Try running the program with 

    node foo.js

Examine package.json to understand how to delcare dependencies
