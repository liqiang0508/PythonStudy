# Chapter 6

Chapter 6 introduces [Express][1], a web framework for node.js and then explores the [Jade][2] Templating Language used by Express.

1. Hello World Server
2. Page structure with Jade
3. Variables in Jade
4. Loops in Jade
5. Conditional statements in Jade
6. Inline JavaScript in Jade
7. Includes in Jade
8. Mixins in Jade

[1]: http://expressjs.com
[2]: http://jade-lang.com/
