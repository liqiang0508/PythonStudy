var express = require('express');
var router = express.Router();
var db = require("../utils/MySql");
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

// router.get('/login', function(req, res, next) {
//    res.send("login");
// });

var Send = function (query, res) {
	console.log("response data= " + query);
    // console.log("response stringify= " + JSON.stringify(query))
	
	// var obj = JSON.parse(query);
	// obj.age = obj.age+20;
	// res.writeHead(200, {'Content-Type': 'application/json'});
    // res.write(JSON.stringify(query));
    // res.end();

    res.send(query);

}

router.post('/login', function(req, res, next) {
  
  console.log("body==",req.body);
   // console.log("body==",req.body.name);


    var postData = req.body;

               
	db.is_account_exist(postData.udid,function(b){
						console.log("is_account_exist",b,postData.udid);
	                    
	                    if(b)//
	                    {
	                        db.get_userInfo(postData,function(data){
	                            console.log("get_userInfo",data[0]); 
	                            Send(data[0],res);
	                            // res.send(data[0]);
	                     });
	                    }
	                    else
	                    {
	                        db.create_account(postData,function(data){
	                            console.log("create_account--",data);  
	                            Send(postData,res);
	                            // res.send(postData);
	                        });
	                    }
	           });



   // console.log("send-----------");	
   // res.send(req.body);
});
module.exports = router;
