var express = require('express');
var path = require('path'); 
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');


var partials = require('express-partials');
var flash = require('connect-flash');
var session = require('express-session'); 

//route
var index = require('./routes/index');
var users = require('./routes/users');
var routes= require('./routes/routes');

var MongoStore = require('connect-mongo')(session);
var settings = require('./settings');

var app = express();



// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(partials());

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());


app.use(express.static(path.join(__dirname, 'public')));

app.use(session({ 
                  // cookie: { maxAge: 60000 }, 
                  secret: settings.cookieSecret,
                  url: 'mongodb://localhost/microblog',
                  // resave: false, 
                  // saveUninitialized: false,
                  // store: new MongoStore({ db: settings.db})
              
                }));
app.use(flash());



// app.get('/', routes.index);
// app.get('/u/:user', routes.user);
// app.post('/post', routes.post);
// app.get('/reg', routes.reg);
// app.post('/reg', routes.doReg);
// app.get('/login', routes.login);
// app.post('/login', routes.doLogin);
// app.get('/logout', routes.logout);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.user = req.session.user;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  var err = req.flash('error');
  var succ = req.flash('success');

  res.locals.error = err.length ? err : null;
  res.locals.success = succ.length ? succ : null;
  next();
  // render the error page
  // res.status(err.status || 500);
  // res.render('error');
});

app.use('/', routes);

// app.dynamicHelpers({
//     user: function(req, res) {
//         return req.session.user;
//       },
//     error: function(req, res) {
//         var err = req.flash('error');
//         if (err.length)
//         return err;
//         else
//         return null;
//     },
//     success: function(req, res) {
//         var succ = req.flash('success');
//         if (succ.length)
//         return succ;
//         else
//         return null;
//     },
// });

module.exports = app;
